﻿namespace WinRAR_Premium_721
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.Combo_ListVersion = new System.Windows.Forms.ComboBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txt_LinkDownload = new System.Windows.Forms.TextBox();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.group_64 = new System.Windows.Forms.GroupBox();
            this.txt_path_64 = new System.Windows.Forms.TextBox();
            this.txt_version_64 = new System.Windows.Forms.TextBox();
            this.group_32 = new System.Windows.Forms.GroupBox();
            this.txt_path_32 = new System.Windows.Forms.TextBox();
            this.txt_version_32 = new System.Windows.Forms.TextBox();
            this.btn_Choise_Folder = new System.Windows.Forms.Button();
            this.txt_Path_Installed = new System.Windows.Forms.TextBox();
            this.label_Path_Installed = new System.Windows.Forms.Label();
            this.Btn_Auto = new System.Windows.Forms.Button();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.MSG_Text = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.label9 = new System.Windows.Forms.Label();
            this.txt_License = new System.Windows.Forms.RichTextBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.txt_company = new System.Windows.Forms.TextBox();
            this.txt_type = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.txt_Console_info = new System.Windows.Forms.RichTextBox();
            this.progressBar = new System.Windows.Forms.ProgressBar();
            this.linkLabel_copyright = new System.Windows.Forms.LinkLabel();
            this.paypal_donate = new System.Windows.Forms.PictureBox();
            this.Pic_LOGO = new System.Windows.Forms.PictureBox();
            this.Pic_copy = new System.Windows.Forms.PictureBox();
            this.status_64 = new System.Windows.Forms.PictureBox();
            this.Check_64 = new System.Windows.Forms.PictureBox();
            this.status_32 = new System.Windows.Forms.PictureBox();
            this.Check_32 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.Create_keygen = new System.Windows.Forms.PictureBox();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.group_64.SuspendLayout();
            this.group_32.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.tabPage4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.paypal_donate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Pic_LOGO)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Pic_copy)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.status_64)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Check_64)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.status_32)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Check_32)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Create_keygen)).BeginInit();
            this.SuspendLayout();
            // 
            // Combo_ListVersion
            // 
            this.Combo_ListVersion.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Combo_ListVersion.FormattingEnabled = true;
            this.Combo_ListVersion.Location = new System.Drawing.Point(111, 42);
            this.Combo_ListVersion.Name = "Combo_ListVersion";
            this.Combo_ListVersion.Size = new System.Drawing.Size(492, 33);
            this.Combo_ListVersion.TabIndex = 0;
            this.Combo_ListVersion.SelectedIndexChanged += new System.EventHandler(this.Combo_ListVersion_SelectedIndexChanged);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.Pic_LOGO);
            this.groupBox1.Controls.Add(this.Pic_copy);
            this.groupBox1.Controls.Add(this.txt_LinkDownload);
            this.groupBox1.Controls.Add(this.Combo_ListVersion);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(254)));
            this.groupBox1.Location = new System.Drawing.Point(6, 6);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(609, 119);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "                    Latest version information";
            // 
            // txt_LinkDownload
            // 
            this.txt_LinkDownload.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(254)));
            this.txt_LinkDownload.Location = new System.Drawing.Point(9, 89);
            this.txt_LinkDownload.Name = "txt_LinkDownload";
            this.txt_LinkDownload.ReadOnly = true;
            this.txt_LinkDownload.Size = new System.Drawing.Size(594, 23);
            this.txt_LinkDownload.TabIndex = 4;
            this.txt_LinkDownload.Click += new System.EventHandler(this.txt_LinkDownload_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.group_64);
            this.groupBox2.Controls.Add(this.group_32);
            this.groupBox2.Controls.Add(this.btn_Choise_Folder);
            this.groupBox2.Controls.Add(this.pictureBox2);
            this.groupBox2.Controls.Add(this.txt_Path_Installed);
            this.groupBox2.Controls.Add(this.label_Path_Installed);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(254)));
            this.groupBox2.Location = new System.Drawing.Point(6, 168);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(609, 178);
            this.groupBox2.TabIndex = 2;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "version information installed on the computer";
            // 
            // group_64
            // 
            this.group_64.BackColor = System.Drawing.Color.Gainsboro;
            this.group_64.Controls.Add(this.status_64);
            this.group_64.Controls.Add(this.Check_64);
            this.group_64.Controls.Add(this.txt_path_64);
            this.group_64.Controls.Add(this.txt_version_64);
            this.group_64.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(254)));
            this.group_64.Location = new System.Drawing.Point(239, 34);
            this.group_64.Name = "group_64";
            this.group_64.Size = new System.Drawing.Size(212, 94);
            this.group_64.TabIndex = 12;
            this.group_64.TabStop = false;
            this.group_64.Text = "WinRAR 64-bit";
            // 
            // txt_path_64
            // 
            this.txt_path_64.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(254)));
            this.txt_path_64.Location = new System.Drawing.Point(17, 60);
            this.txt_path_64.Name = "txt_path_64";
            this.txt_path_64.ReadOnly = true;
            this.txt_path_64.Size = new System.Drawing.Size(180, 20);
            this.txt_path_64.TabIndex = 1;
            this.txt_path_64.Text = "**************************************************";
            // 
            // txt_version_64
            // 
            this.txt_version_64.Enabled = false;
            this.txt_version_64.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(254)));
            this.txt_version_64.Location = new System.Drawing.Point(17, 30);
            this.txt_version_64.Name = "txt_version_64";
            this.txt_version_64.ReadOnly = true;
            this.txt_version_64.Size = new System.Drawing.Size(180, 23);
            this.txt_version_64.TabIndex = 0;
            this.txt_version_64.Text = "**************************************************";
            this.txt_version_64.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // group_32
            // 
            this.group_32.BackColor = System.Drawing.Color.Gainsboro;
            this.group_32.Controls.Add(this.status_32);
            this.group_32.Controls.Add(this.Check_32);
            this.group_32.Controls.Add(this.txt_path_32);
            this.group_32.Controls.Add(this.txt_version_32);
            this.group_32.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(254)));
            this.group_32.Location = new System.Drawing.Point(9, 34);
            this.group_32.Name = "group_32";
            this.group_32.Size = new System.Drawing.Size(212, 94);
            this.group_32.TabIndex = 11;
            this.group_32.TabStop = false;
            this.group_32.Text = "WinRAR 32-bit";
            // 
            // txt_path_32
            // 
            this.txt_path_32.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(254)));
            this.txt_path_32.Location = new System.Drawing.Point(17, 60);
            this.txt_path_32.Name = "txt_path_32";
            this.txt_path_32.ReadOnly = true;
            this.txt_path_32.Size = new System.Drawing.Size(180, 20);
            this.txt_path_32.TabIndex = 1;
            this.txt_path_32.Text = "**************************************************";
            // 
            // txt_version_32
            // 
            this.txt_version_32.Enabled = false;
            this.txt_version_32.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(254)));
            this.txt_version_32.Location = new System.Drawing.Point(17, 30);
            this.txt_version_32.Name = "txt_version_32";
            this.txt_version_32.ReadOnly = true;
            this.txt_version_32.Size = new System.Drawing.Size(180, 23);
            this.txt_version_32.TabIndex = 0;
            this.txt_version_32.Text = "**************************************************";
            this.txt_version_32.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // btn_Choise_Folder
            // 
            this.btn_Choise_Folder.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel, ((byte)(254)));
            this.btn_Choise_Folder.Location = new System.Drawing.Point(526, 136);
            this.btn_Choise_Folder.Name = "btn_Choise_Folder";
            this.btn_Choise_Folder.Size = new System.Drawing.Size(83, 37);
            this.btn_Choise_Folder.TabIndex = 10;
            this.btn_Choise_Folder.Text = "Change";
            this.btn_Choise_Folder.UseVisualStyleBackColor = true;
            this.btn_Choise_Folder.Click += new System.EventHandler(this.btn_Choise_Folder_Click);
            // 
            // txt_Path_Installed
            // 
            this.txt_Path_Installed.Location = new System.Drawing.Point(59, 139);
            this.txt_Path_Installed.Name = "txt_Path_Installed";
            this.txt_Path_Installed.ReadOnly = true;
            this.txt_Path_Installed.Size = new System.Drawing.Size(484, 30);
            this.txt_Path_Installed.TabIndex = 8;
            // 
            // label_Path_Installed
            // 
            this.label_Path_Installed.AutoSize = true;
            this.label_Path_Installed.Cursor = System.Windows.Forms.Cursors.Hand;
            this.label_Path_Installed.Location = new System.Drawing.Point(4, 142);
            this.label_Path_Installed.Name = "label_Path_Installed";
            this.label_Path_Installed.Size = new System.Drawing.Size(58, 25);
            this.label_Path_Installed.TabIndex = 7;
            this.label_Path_Installed.Text = "Path:";
            this.label_Path_Installed.Click += new System.EventHandler(this.label_Path_Installed_Click);
            // 
            // Btn_Auto
            // 
            this.Btn_Auto.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Btn_Auto.Enabled = false;
            this.Btn_Auto.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Btn_Auto.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(254)));
            this.Btn_Auto.Location = new System.Drawing.Point(13, 424);
            this.Btn_Auto.Name = "Btn_Auto";
            this.Btn_Auto.Size = new System.Drawing.Size(265, 61);
            this.Btn_Auto.TabIndex = 3;
            this.Btn_Auto.Text = "Wait...";
            this.Btn_Auto.UseVisualStyleBackColor = true;
            this.Btn_Auto.Click += new System.EventHandler(this.Btn_Auto_Click);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(254)));
            this.tabControl1.Location = new System.Drawing.Point(13, 13);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(629, 395);
            this.tabControl1.TabIndex = 5;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.MSG_Text);
            this.tabPage1.Controls.Add(this.groupBox1);
            this.tabPage1.Controls.Add(this.groupBox2);
            this.tabPage1.Location = new System.Drawing.Point(4, 34);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(621, 357);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Software information";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // MSG_Text
            // 
            this.MSG_Text.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(254)));
            this.MSG_Text.Location = new System.Drawing.Point(3, 128);
            this.MSG_Text.Name = "MSG_Text";
            this.MSG_Text.Size = new System.Drawing.Size(612, 38);
            this.MSG_Text.TabIndex = 3;
            this.MSG_Text.Text = "loading...";
            this.MSG_Text.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.label9);
            this.tabPage2.Controls.Add(this.txt_License);
            this.tabPage2.Controls.Add(this.groupBox3);
            this.tabPage2.Location = new System.Drawing.Point(4, 34);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(621, 357);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Registration information";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(3, 148);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(86, 25);
            this.label9.TabIndex = 4;
            this.label9.Text = "License:";
            // 
            // txt_License
            // 
            this.txt_License.BackColor = System.Drawing.Color.PeachPuff;
            this.txt_License.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(254)));
            this.txt_License.Location = new System.Drawing.Point(4, 176);
            this.txt_License.Name = "txt_License";
            this.txt_License.ReadOnly = true;
            this.txt_License.Size = new System.Drawing.Size(611, 173);
            this.txt_License.TabIndex = 3;
            this.txt_License.Text = "";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.Create_keygen);
            this.groupBox3.Controls.Add(this.txt_company);
            this.groupBox3.Controls.Add(this.txt_type);
            this.groupBox3.Controls.Add(this.label3);
            this.groupBox3.Controls.Add(this.label4);
            this.groupBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(254)));
            this.groupBox3.Location = new System.Drawing.Point(6, 6);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(609, 141);
            this.groupBox3.TabIndex = 2;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Copyright registration information";
            // 
            // txt_company
            // 
            this.txt_company.BackColor = System.Drawing.Color.PeachPuff;
            this.txt_company.Location = new System.Drawing.Point(186, 45);
            this.txt_company.Name = "txt_company";
            this.txt_company.ReadOnly = true;
            this.txt_company.Size = new System.Drawing.Size(417, 30);
            this.txt_company.TabIndex = 5;
            this.txt_company.Text = "721PC-Net Corporation";
            // 
            // txt_type
            // 
            this.txt_type.BackColor = System.Drawing.Color.PeachPuff;
            this.txt_type.Location = new System.Drawing.Point(186, 89);
            this.txt_type.Name = "txt_type";
            this.txt_type.ReadOnly = true;
            this.txt_type.Size = new System.Drawing.Size(417, 30);
            this.txt_type.TabIndex = 4;
            this.txt_type.Text = "Unlimited Company License";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(107, 89);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(63, 25);
            this.label3.TabIndex = 3;
            this.label3.Text = "Type:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(10, 45);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(160, 25);
            this.label4.TabIndex = 1;
            this.label4.Text = "Company Name:";
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.txt_Console_info);
            this.tabPage4.Location = new System.Drawing.Point(4, 34);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(621, 357);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Console";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // txt_Console_info
            // 
            this.txt_Console_info.BackColor = System.Drawing.SystemColors.ControlLight;
            this.txt_Console_info.Location = new System.Drawing.Point(7, 7);
            this.txt_Console_info.Name = "txt_Console_info";
            this.txt_Console_info.ReadOnly = true;
            this.txt_Console_info.Size = new System.Drawing.Size(608, 335);
            this.txt_Console_info.TabIndex = 0;
            this.txt_Console_info.Text = "English Version\n\nSetup 64-bit:\nYourApp.exe /setup 64bit\n\nSetup 32-bit:\nYourApp.ex" +
    "e /setup 32bit\n\nSetup beta:\nYourApp.exe /setup beta";
            // 
            // progressBar
            // 
            this.progressBar.Location = new System.Drawing.Point(14, 395);
            this.progressBar.Name = "progressBar";
            this.progressBar.Size = new System.Drawing.Size(626, 20);
            this.progressBar.TabIndex = 11;
            // 
            // linkLabel_copyright
            // 
            this.linkLabel_copyright.AutoSize = true;
            this.linkLabel_copyright.Location = new System.Drawing.Point(484, 470);
            this.linkLabel_copyright.Name = "linkLabel_copyright";
            this.linkLabel_copyright.Size = new System.Drawing.Size(167, 13);
            this.linkLabel_copyright.TabIndex = 13;
            this.linkLabel_copyright.TabStop = true;
            this.linkLabel_copyright.Text = "(C) 2025 721PC-Net® Corporation";
            this.linkLabel_copyright.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel_copyright_LinkClicked);
            // 
            // paypal_donate
            // 
            this.paypal_donate.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.paypal_donate.Cursor = System.Windows.Forms.Cursors.Hand;
            this.paypal_donate.Image = global::WinRAR_Premium_721.Properties.Resources.paypal_donate_100x29;
            this.paypal_donate.Location = new System.Drawing.Point(515, 12);
            this.paypal_donate.Name = "paypal_donate";
            this.paypal_donate.Size = new System.Drawing.Size(127, 30);
            this.paypal_donate.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.paypal_donate.TabIndex = 14;
            this.paypal_donate.TabStop = false;
            this.paypal_donate.Click += new System.EventHandler(this.paypal_donate_Click);
            // 
            // Pic_LOGO
            // 
            this.Pic_LOGO.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.Pic_LOGO.Image = ((System.Drawing.Image)(resources.GetObject("Pic_LOGO.Image")));
            this.Pic_LOGO.Location = new System.Drawing.Point(9, 0);
            this.Pic_LOGO.Name = "Pic_LOGO";
            this.Pic_LOGO.Size = new System.Drawing.Size(96, 89);
            this.Pic_LOGO.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Pic_LOGO.TabIndex = 13;
            this.Pic_LOGO.TabStop = false;
            // 
            // Pic_copy
            // 
            this.Pic_copy.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.Pic_copy.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Pic_copy.Image = global::WinRAR_Premium_721.Properties.Resources.Copy;
            this.Pic_copy.Location = new System.Drawing.Point(575, 76);
            this.Pic_copy.Name = "Pic_copy";
            this.Pic_copy.Size = new System.Drawing.Size(28, 35);
            this.Pic_copy.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Pic_copy.TabIndex = 10;
            this.Pic_copy.TabStop = false;
            this.Pic_copy.Click += new System.EventHandler(this.Pic_copy_Click);
            // 
            // status_64
            // 
            this.status_64.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.status_64.Image = global::WinRAR_Premium_721.Properties.Resources.installed;
            this.status_64.Location = new System.Drawing.Point(6, 23);
            this.status_64.Name = "status_64";
            this.status_64.Size = new System.Drawing.Size(33, 34);
            this.status_64.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.status_64.TabIndex = 13;
            this.status_64.TabStop = false;
            this.status_64.Visible = false;
            // 
            // Check_64
            // 
            this.Check_64.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.Check_64.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Check_64.Image = global::WinRAR_Premium_721.Properties.Resources.not_installed;
            this.Check_64.Location = new System.Drawing.Point(184, 2);
            this.Check_64.Name = "Check_64";
            this.Check_64.Size = new System.Drawing.Size(28, 29);
            this.Check_64.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Check_64.TabIndex = 10;
            this.Check_64.TabStop = false;
            this.Check_64.Click += new System.EventHandler(this.Check_64_Click);
            // 
            // status_32
            // 
            this.status_32.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.status_32.Image = global::WinRAR_Premium_721.Properties.Resources.installed;
            this.status_32.Location = new System.Drawing.Point(6, 19);
            this.status_32.Name = "status_32";
            this.status_32.Size = new System.Drawing.Size(33, 34);
            this.status_32.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.status_32.TabIndex = 12;
            this.status_32.TabStop = false;
            this.status_32.Visible = false;
            // 
            // Check_32
            // 
            this.Check_32.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.Check_32.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Check_32.Image = global::WinRAR_Premium_721.Properties.Resources.not_installed;
            this.Check_32.Location = new System.Drawing.Point(183, 2);
            this.Check_32.Name = "Check_32";
            this.Check_32.Size = new System.Drawing.Size(27, 29);
            this.Check_32.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Check_32.TabIndex = 11;
            this.Check_32.TabStop = false;
            this.Check_32.Click += new System.EventHandler(this.Check_32_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.pictureBox2.Image = global::WinRAR_Premium_721.Properties.Resources.Microsoft_Certified_IT_Professional1;
            this.pictureBox2.Location = new System.Drawing.Point(457, 34);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(152, 94);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 9;
            this.pictureBox2.TabStop = false;
            // 
            // Create_keygen
            // 
            this.Create_keygen.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.Create_keygen.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Create_keygen.Image = global::WinRAR_Premium_721.Properties.Resources.Sync_1;
            this.Create_keygen.Location = new System.Drawing.Point(15, 66);
            this.Create_keygen.Name = "Create_keygen";
            this.Create_keygen.Size = new System.Drawing.Size(71, 69);
            this.Create_keygen.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Create_keygen.TabIndex = 6;
            this.Create_keygen.TabStop = false;
            this.Create_keygen.Click += new System.EventHandler(this.Create_keygen_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLight;
            this.ClientSize = new System.Drawing.Size(652, 488);
            this.Controls.Add(this.paypal_donate);
            this.Controls.Add(this.linkLabel_copyright);
            this.Controls.Add(this.progressBar);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.Btn_Auto);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "WinRAR Premium <<2025>> 721PC-Net Corporation";
            this.TopMost = true;
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.group_64.ResumeLayout(false);
            this.group_64.PerformLayout();
            this.group_32.ResumeLayout(false);
            this.group_32.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.tabPage4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.paypal_donate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Pic_LOGO)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Pic_copy)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.status_64)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Check_64)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.status_32)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Check_32)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Create_keygen)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox Combo_ListVersion;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.TextBox txt_LinkDownload;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox txt_Path_Installed;
        private System.Windows.Forms.Label label_Path_Installed;
        private System.Windows.Forms.Button Btn_Auto;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TextBox txt_type;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.RichTextBox txt_License;
        private System.Windows.Forms.TextBox txt_company;
        private System.Windows.Forms.PictureBox Create_keygen;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox Pic_copy;
        private System.Windows.Forms.Label MSG_Text;
        private System.Windows.Forms.ProgressBar progressBar;
        private System.Windows.Forms.PictureBox Pic_LOGO;
        private System.Windows.Forms.Button btn_Choise_Folder;
        private System.Windows.Forms.GroupBox group_32;
        private System.Windows.Forms.TextBox txt_path_32;
        private System.Windows.Forms.TextBox txt_version_32;
        private System.Windows.Forms.GroupBox group_64;
        private System.Windows.Forms.TextBox txt_path_64;
        private System.Windows.Forms.TextBox txt_version_64;
        private System.Windows.Forms.PictureBox Check_64;
        private System.Windows.Forms.PictureBox Check_32;
        private System.Windows.Forms.PictureBox status_32;
        private System.Windows.Forms.PictureBox status_64;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.RichTextBox txt_Console_info;
        private System.Windows.Forms.LinkLabel linkLabel_copyright;
        private System.Windows.Forms.PictureBox paypal_donate;
    }
}

