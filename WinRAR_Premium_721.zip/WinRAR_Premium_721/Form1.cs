﻿using Microsoft.Win32;
using Newtonsoft.Json.Linq;
using System;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Net.NetworkInformation;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WinRAR_Premium_721;
using WinRAR_Premium_721.Models;
using WinRAR_Premium_721.Services;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace WinRAR_Premium_721
{
    public partial class Form1 : Form
    {

        private Image originalImage;
        private Image newImage;
        private bool isRotating = false;
        private int rotationAngle = 0;
        private Timer rotationTimer;
        private WinrarData _winrarData;
        private const string InstallText = "Install Now";
        private const string DownloadText = "Download";
        private string architecture = "NotInstall";
        private bool isInstall = false;
        private bool isDelete32 = false;
        private bool isDelete64 = false;

        public Form1()
        {
            InitializeComponent();
            FormSetBottomRight();
            LockForm();

            originalImage = global::WinRAR_Premium_721.Properties.Resources.Sync_1;
            newImage = global::WinRAR_Premium_721.Properties.Resources.Sync_2;

            this.Create_keygen.Image = originalImage;

            rotationTimer = new Timer();
            rotationTimer.Interval = 3;
            rotationTimer.Tick += RotationTimer_Tick;
        }
        public static bool Is64BitOS()
        {
            return Environment.Is64BitOperatingSystem;
        }
        private void LockForm()
        {

            btn_Choise_Folder.Enabled = false;
            Btn_Auto.Enabled = false;

        }
        private void UnlockForm()
        {

            btn_Choise_Folder.Enabled = true;
            Btn_Auto.Enabled = true;
        }
        private void Create_keygen_Click(object sender, EventArgs e)
        {
            if (!isRotating)
            {

                isRotating = true;
                this.Create_keygen.Image = newImage;
                rotationAngle = 0;
                rotationTimer.Enabled = true;

                CreateKeygen();
            }
        }

        private async void Form1_Load(object sender, EventArgs e)
        {
            txt_version_32.Text = architecture;
            txt_version_64.Text = architecture;
            txt_path_64.Text = architecture;
            txt_path_32.Text = architecture;
            txt_path_64.Text = architecture;
            txt_Console_info.Text = Console_info();

            await ShowBlinkMessage("Vui lòng đợi trong giây lát... Đang tải dữ liệu...", Color.Red, Color.YellowGreen);
            CreateKeygen();
            await LoadVersionsToComboBox();
            Check_Status_Winrar();
            UnlockForm();

        }

        private string Get_ProgramFile_Winrar(string text)
        {
            Winrar_Check winrarCheck = new Winrar_Check();
            var architectureAndLocation = winrarCheck.CheckArchitectureAndInstallLocationFromUrl(text);
            var installLocation = architectureAndLocation.installLocation;

            if (installLocation != "NotInstall")
            {

                return System.IO.Path.Combine(installLocation, "");
            }

            string fileName = winrarCheck.ExtractFileNameFromUrl(text).ToLower();

            if (Is64BitOS())
            {
                if (fileName.Contains("x64"))
                {
                    string programFiles64 = Environment.GetEnvironmentVariable("ProgramW6432")
                                            ?? Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles);
                    return System.IO.Path.Combine(programFiles64, "Winrar");
                }
                else
                {
                    string programFiles86 = Environment.GetEnvironmentVariable("ProgramFiles(x86)")
                                            ?? Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86);
                    return System.IO.Path.Combine(programFiles86, "Winrar");
                }
            }
            else
            {
                string programFiles = Environment.GetEnvironmentVariable("ProgramFiles")
                                      ?? Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles);
                return System.IO.Path.Combine(programFiles, "Winrar");
            }
        }

        private void Check_Status_Winrar()
        {
            Winrar_Check winrarCheck = new Winrar_Check();
            var result32 = winrarCheck.CheckWinRARInstallLocation(32);
            txt_version_32.Text = result32.architecture;
            txt_path_32.Text = result32.installLocation;
            if (result32.architecture != architecture)
            {
                this.Check_32.Image = global::WinRAR_Premium_721.Properties.Resources.Delete;
                this.status_32.Visible = true;
                isDelete32 = true;
                string version32 = winrarCheck.GetWinRARVersion(RegistryView.Registry32);
                group_32.Text = $"WinRAR 32-bit {version32}";
            }
            else
            {
                this.Check_32.Image = global::WinRAR_Premium_721.Properties.Resources.not_installed;
                this.status_32.Visible = false;
                isDelete32 = false;
            }
            txt_Path_Installed.Text = Get_ProgramFile_Winrar(txt_LinkDownload.Text);

            var result64 = winrarCheck.CheckWinRARInstallLocation(64);
            txt_version_64.Text = result64.architecture;
            txt_path_64.Text = result64.installLocation;

            if (result64.architecture != architecture)
            {
                this.Check_64.Image = global::WinRAR_Premium_721.Properties.Resources.Delete;
                this.status_64.Visible = true;
                isDelete64 = true;
                string version64 = winrarCheck.GetWinRARVersion(RegistryView.Registry64);
                group_64.Text = $"WinRAR 64-bit {version64}";
            }
            else
            {
                this.Check_64.Image = global::WinRAR_Premium_721.Properties.Resources.not_installed;
                this.status_64.Visible = false;
                isDelete64 = false;
            }
        }

        private async Task LoadVersionsToComboBox()
        {
            try
            {
                WinrarApiClient apiClient = new WinrarApiClient();
                _winrarData = await apiClient.GetWinrarVersionAsync();

                if (_winrarData != null)
                {
                    Combo_ListVersion.Items.Clear();

                    if (!string.IsNullOrEmpty(_winrarData.VersionBeta))
                    {
                        var betaItem = new VersionItem { Name = _winrarData.VersionBeta, Tag = "Beta" };
                        Combo_ListVersion.Items.Add(betaItem);
                    }

                    var currentItem = new VersionItem { Name = _winrarData.VersionCurrent, Tag = "Current" };
                    Combo_ListVersion.Items.Add(currentItem);

                    var currentItem32 = new VersionItem { Name = _winrarData.Versioncurrent32, Tag = "Current" };
                    Combo_ListVersion.Items.Add(currentItem32);

                    if (_winrarData.ListVersion != null)
                    {
                        foreach (var version in _winrarData.ListVersion)
                        {
                            Combo_ListVersion.Items.Add(new VersionItem { Name = version.Name });
                        }
                    }

                    if (Combo_ListVersion.Items.Count > 0)
                    {
                        Combo_ListVersion.SelectedIndex = 0;
                    }
                }
            }
            catch (Exception ex)
            {

                ShowBlinkMessage("Không thể tải dữ liệu. Kiểm tra kết nối internet...", Color.Red, Color.YellowGreen);
            }
        }

        private void Combo_ListVersion_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (Combo_ListVersion.SelectedItem is VersionItem selectedItem)
            {
                string link = string.Empty;

                if (selectedItem.Name == _winrarData.VersionBeta)
                {
                    link = _winrarData.LinkBeta;
                }
                else if (selectedItem.Name == _winrarData.VersionCurrent)
                {
                    link = _winrarData.LinkCurrent;
                }
                else if (selectedItem.Name == _winrarData.Versioncurrent32)
                {
                    link = _winrarData.LinkCurrent32;
                }
                else
                {

                    var matchedVersion = _winrarData.ListVersion?.FirstOrDefault(v => v.Name == selectedItem.Name);
                    if (matchedVersion != null)
                    {
                        link = matchedVersion.Link;
                    }
                }

                txt_LinkDownload.Text = link;

                if (!string.IsNullOrEmpty(link))
                {

                    string extension = System.IO.Path.GetExtension(link);

                    if (extension.Equals(".exe", StringComparison.OrdinalIgnoreCase))
                    {
                        Btn_Auto.Text = InstallText;
                        isInstall = true;
                        txt_Path_Installed.Text = Get_ProgramFile_Winrar(link);
                    }
                    else
                    {
                        Btn_Auto.Text = DownloadText;
                        isInstall = false;
                    }
                }
                else
                {

                    Btn_Auto.Text = "Waiting...";
                    isInstall = false;
                }
            }
        }
        private async Task<string> GetLicenseContentAsync()
        {
            try
            {
                WinrarApiClient apiClient = new WinrarApiClient();
                WinrarData winrarData = await apiClient.GetWinrarVersionAsync();

                if (winrarData != null && !string.IsNullOrEmpty(winrarData.KeyCopyright))
                {
                    string keyUrl = winrarData.KeyCopyright;
                    using (HttpClient client = new HttpClient())
                    {
                        client.DefaultRequestHeaders.Add("User-Agent", "Mozilla/5.0");
                        return await client.GetStringAsync(keyUrl);
                    }
                }

                return null;
            }
            catch (Exception ex)
            {
                await ShowBlinkMessage("Đã xảy ra lỗi khi lấy license. Hãy kiểm tra kết nối internet...", Color.Red, Color.YellowGreen);
                return null;
            }
        }
        private async void CreateKeygen()
        {

            string username = txt_company.Text.Trim();
            string license = txt_type.Text.Trim();
            string keyString = string.Empty;
            txt_License.Text = "loading...";
            string licenseContent = await GetLicenseContentAsync();
            if (licenseContent != null)
            {
                txt_License.Text = licenseContent;
            }
            else
            {
                txt_License.Text = "Không thể lấy nội dung license.Kiểm tra kết nối mạng...";
            }
        }

        private void RotationTimer_Tick(object sender, EventArgs e)
        {
            rotationAngle += 15;
            if (rotationAngle >= 360)
            {

                rotationAngle = 0;
                rotationTimer.Enabled = false;
                isRotating = false;
                this.Create_keygen.Image = originalImage;
            }
            else
            {

                Image rotatedImage = new Bitmap(newImage.Width, newImage.Height);
                using (Graphics g = Graphics.FromImage(rotatedImage))
                {

                    g.TranslateTransform((float)newImage.Width / 2, (float)newImage.Height / 2);
                    g.RotateTransform(rotationAngle);
                    g.TranslateTransform(-(float)newImage.Width / 2, -(float)newImage.Height / 2);
                    g.DrawImage(newImage, 0, 0);
                }
                this.Create_keygen.Image = rotatedImage;
            }
        }

        private void txt_LinkDownload_Click(object sender, EventArgs e)
        {

        }

        private async void Pic_copy_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txt_LinkDownload.Text))
            {
                Clipboard.SetText(txt_LinkDownload.Text);
                await ShowBlinkMessage("Đã copy link!", Color.Green, Color.Blue);
            }
            else
            {
                await ShowBlinkMessage("Không có gì để copy!", Color.Red, Color.Orange);
            }
        }

        private async Task ShowBlinkMessage(string message, Color color1, Color color2, int blinkCount = 6, int blinkInterval = 200)
        {
            MSG_Text.Text = message;

            for (int i = 0; i < blinkCount; i++)
            {
                MSG_Text.ForeColor = (i % 2 == 0) ? color1 : color2;
                await Task.Delay(blinkInterval);
            }

            MSG_Text.Text = string.Empty;
            MSG_Text.ForeColor = Color.Black;
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {

            if (rotationTimer != null && rotationTimer.Enabled)
            {
                rotationTimer.Stop();
            }
        }

        private async void Btn_Auto_Click(object sender, EventArgs e)
        {
            Btn_Auto.Enabled = false;
            progressBar.Value = 0;

            string downloadLink = txt_LinkDownload.Text;
            if (string.IsNullOrEmpty(downloadLink))
            {
                await ShowBlinkMessage("Không có đường dẫn tải xuống.", Color.Red, Color.Orange);
                Btn_Auto.Enabled = true;
                return;
            }

            Winrar_Check winrarCheck = new Winrar_Check();

            var fileInfo = winrarCheck.CheckArchitectureAndInstallLocationFromUrl(downloadLink);
            string selectedArch = fileInfo.architecture;

            if (!Environment.Is64BitOperatingSystem && selectedArch.Contains("64-bit"))
            {
                await ShowBlinkMessage("Bạn không thể cài đặt phiên bản 64-bit trên hệ điều hành 32-bit.", Color.Red, Color.Orange);
                return;
            }
            try
            {
                string folderPath = Path.Combine(Application.StartupPath, "Winrar_Version");
                string fileName = Path.GetFileName(new Uri(downloadLink).LocalPath);
                string filePath = Path.Combine(folderPath, fileName);

                await ShowBlinkMessage("Đang tải xuống...", Color.Orange, Color.Red);

                var progressIndicator = new Progress<int>(percent =>
                {

                    progressBar.Value = percent;

                    MSG_Text.Text = $"Downloading...{percent}%";
                });

                await DownloadFileAsync(downloadLink, filePath, progressIndicator);

                if (File.Exists(filePath))
                {
                    if (isInstall)
                    {
                        await ShowBlinkMessage("Tải xuống hoàn tất. Đang cài đặt...", Color.Green, Color.LightGreen);
                        progressBar.Value = 0;
                        MSG_Text.Text = "";

                        Process process = Process.Start(new ProcessStartInfo(filePath) { Arguments = "/S /D\"" + txt_Path_Installed.Text.Trim() + "\"" });

                        process.WaitForExit();

                        string installPath = txt_Path_Installed.Text;
                        string licenseContent = txt_License.Text;

                        if (await WriteLicenseFile(licenseContent, installPath))
                        {
                            await ShowBlinkMessage("Cài đặt và kích hoạt WinRAR thành công!", Color.Green, Color.Blue);
                        }
                        else
                        {
                            await ShowBlinkMessage("Cài đặt xong, nhưng ghi file license thất bại.", Color.Red, Color.Orange);
                        }
                    }
                    else
                    {
                        await ShowBlinkMessage($"Tải xuống hoàn tất: {filePath}", Color.Green, Color.LightGreen);
                    }
                }
                else
                {
                    await ShowBlinkMessage("Lỗi: Không tìm thấy file đã tải xuống.", Color.Red, Color.Orange);
                }
            }
            catch (Exception ex)
            {
                await ShowBlinkMessage($"Lỗi: {ex.Message}", Color.Red, Color.Orange);
            }
            finally
            {
                Btn_Auto.Enabled = true;
                Check_Status_Winrar();

            }
        }

        private async Task DownloadFileAsync(string url, string filePath, IProgress<int> progress)
        {
            using (HttpClient client = new HttpClient())
            {
                string directory = Path.GetDirectoryName(filePath);
                if (!Directory.Exists(directory))
                {
                    Directory.CreateDirectory(directory);
                }

                HttpResponseMessage response = await client.GetAsync(url, HttpCompletionOption.ResponseHeadersRead);
                response.EnsureSuccessStatusCode();

                long? totalBytes = response.Content.Headers.ContentLength;
                if (!totalBytes.HasValue)
                {

                    progress.Report(0);
                    using (var contentStream = await response.Content.ReadAsStreamAsync())
                    using (var fileStream = new FileStream(filePath, FileMode.Create, FileAccess.Write, FileShare.None))
                    {
                        await contentStream.CopyToAsync(fileStream);
                    }
                    progress.Report(100);
                    return;
                }

                using (var fileStream = new FileStream(filePath, FileMode.Create, FileAccess.Write, FileShare.None))
                using (var contentStream = await response.Content.ReadAsStreamAsync())
                {
                    var buffer = new byte[81920];
                    long bytesRead = 0;
                    int bytesReceived;
                    while ((bytesReceived = await contentStream.ReadAsync(buffer, 0, buffer.Length)) > 0)
                    {
                        await fileStream.WriteAsync(buffer, 0, bytesReceived);
                        bytesRead += bytesReceived;
                        int percent = (int)((double)bytesRead / totalBytes.Value * 100);
                        progress.Report(percent);
                    }
                }
            }
        }

        private async Task<bool> WriteLicenseFile(string licenseContent, string installPath)
        {
            if (string.IsNullOrEmpty(licenseContent) || string.IsNullOrEmpty(installPath))
            {
                await ShowBlinkMessage("Lỗi: Thiếu nội dung license hoặc đường dẫn cài đặt.", Color.Red, Color.Orange);
                return false;
            }

            try
            {
                string licenseFilePath = Path.Combine(installPath, "rarreg.key");

                if (Directory.Exists(installPath))
                {

                    File.WriteAllText(licenseFilePath, licenseContent, Encoding.ASCII);
                    return true;
                }
                else
                {
                    await ShowBlinkMessage("Lỗi: Thư mục cài đặt không tồn tại.", Color.Red, Color.Orange);
                    return false;
                }
            }
            catch (UnauthorizedAccessException)
            {

                await ShowBlinkMessage("Lỗi quyền: Vui lòng chạy ứng dụng với quyền Admin để ghi file.", Color.Red, Color.Orange);
                return false;
            }
            catch (Exception ex)
            {
                await ShowBlinkMessage($"Lỗi khi ghi file license: {ex.Message}", Color.Red, Color.Orange);
                return false;
            }
        }

        private async void label_Path_Installed_Click(object sender, EventArgs e)
        {
            try
            {

                string folderPath = txt_Path_Installed.Text;

                if (Directory.Exists(folderPath))
                {

                    System.Diagnostics.Process.Start("explorer.exe", folderPath);
                }
                else
                {

                    await ShowBlinkMessage("Thư mục không tồn tại.", Color.Red, Color.White);
                }
            }
            catch (UnauthorizedAccessException)
            {

                await ShowBlinkMessage("Lỗi quyền: Vui lòng chạy ứng dụng với quyền Admin để ghi file.", Color.Red, Color.Orange);
            }
            catch (Exception ex)
            {

                await ShowBlinkMessage($"Đã có lỗi xảy ra: {ex.Message}", Color.Red, Color.White);
            }
        }

        private void Check_64_Click(object sender, EventArgs e)
        {
            if (isDelete64)
            {
                string uninstallPath = Path.Combine(txt_path_64.Text, "Uninstall.exe");
                UninstallWinRAR(uninstallPath);
                group_64.Text = "WinRAR 64-bit";
            }

        }

        private void Check_32_Click(object sender, EventArgs e)
        {

            if (isDelete32)
            {
                string uninstallPath = Path.Combine(txt_path_32.Text, "Uninstall.exe");
                UninstallWinRAR(uninstallPath);
                group_32.Text = "WinRAR 32-bit";
            }

        }

        private void UninstallWinRAR(string uninstallPath)
        {
            if (File.Exists(uninstallPath))
            {
                try
                {

                    ProcessStartInfo startInfo = new ProcessStartInfo
                    {
                        FileName = uninstallPath,
                        Arguments = "/S",
                        UseShellExecute = false,
                        Verb = "runas"
                    };

                    Process process = Process.Start(startInfo);
                    process.WaitForExit();
                    Check_Status_Winrar();
                    ShowBlinkMessage("WinRAR đã được gỡ bỏ thành công!", Color.Blue, Color.Red);
                }
                catch (Exception ex)
                {
                    ShowBlinkMessage("Lỗi khi gỡ bỏ WinRAR: " + ex.Message, Color.Red, Color.White);
                }
            }
            else
            {
                ShowBlinkMessage("Không tìm thấy Uninstall.exe tại " + uninstallPath, Color.Red, Color.White);
            }
        }

        private void btn_Choise_Folder_Click(object sender, EventArgs e)
        {

            using (FolderBrowserDialog folderDialog = new FolderBrowserDialog())
            {

                DriveInfo[] drives = DriveInfo.GetDrives();
                string initialPath = @"C:\"; // Mặc định ổ C:

                if (drives.Length > 0)
                {

                    initialPath = drives[0].RootDirectory.FullName;
                }

                folderDialog.SelectedPath = initialPath;

                if (folderDialog.ShowDialog() == DialogResult.OK)
                {
                    string path_setup = Path.Combine(folderDialog.SelectedPath, "Winrar");
                    txt_Path_Installed.Text = path_setup;
                }
            }
        }

        private string Console_info()
        {

            string appName = AppDomain.CurrentDomain.FriendlyName;
            string result = $@"
English Version
note: need internet connection.

Setup 64-bit:
{appName} /setup 64bit

Setup 32-bit:
{appName} /setup 32bit

Setup beta:
{appName} /setup beta
";
            return result;
        }

        private void linkLabel_copyright_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            try
            {

                Process.Start("https://fb.com/721PC");
            }
            catch (Exception ex)
            {
                ShowBlinkMessage($"Không thể mở trình duyệt: {ex.Message}", Color.Red, Color.White);
            }
        }

        public void FormSetBottomRight()
        {
            this.StartPosition = FormStartPosition.Manual;
            this.Location = new Point(Screen.PrimaryScreen.WorkingArea.Width - this.Width, Screen.PrimaryScreen.WorkingArea.Height - this.Height);
        }

        private void paypal_donate_Click(object sender, EventArgs e)
        {
            try
            {

                Process.Start("https://paypal.me/danieldac1819");
            }
            catch (Exception ex)
            {
                ShowBlinkMessage($"Không thể mở trình duyệt: {ex.Message}", Color.Red, Color.White);
            }
        }
    }
}