﻿using Newtonsoft.Json;
using System.Collections.Generic;

namespace WinRAR_Premium_721.Models
{
    public class VersionItem
    {
        public string Name { get; set; }
        public string Tag { get; set; }

        public override string ToString()
        {
            if (!string.IsNullOrEmpty(Tag))
            {
                return $"{Name} ({Tag})";
            }
            return Name;
        }
    }
    public class WinrarVersion
    {
        public string Name { get; set; }
        public string Link { get; set; }
        public string Size { get; set; }
        public string Platform { get; set; }
    }

    public class WinrarData
    {
        [JsonProperty("KeyCopyRight")]
        public string KeyCopyright { get; set; }
        public string VersionBeta { get; set; }
        public string LinkBeta { get; set; }
        public string NumberversionCurrent { get; set; }
        public string VersionCurrent { get; set; }
        public string LinkCurrent { get; set; }
        public string SizeCurrent { get; set; }
        public string PlatformCurrent { get; set; }
        public string Versioncurrent32 { get; set; }
        public string LinkCurrent32 { get; set; }
        public List<WinrarVersion> ListVersion { get; set; }
    }
}