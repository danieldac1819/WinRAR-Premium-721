﻿using Microsoft.Win32;
using System;
using System.IO;
using System.Text.RegularExpressions;
using WinRAR_Premium_721.Services;

namespace WinRAR_Premium_721.Models
{
    public class Winrar_Check
    {
        private const string Architecture32Bit = "32-bit";
        private const string Architecture64Bit = "64-bit";
        private const string NotInstall = "NotInstall";

        public (string architecture, string installLocation) CheckWinRARInstallLocation(int bitVersion = 0)
        {
            string installLocation = null;
            string architecture = NotInstall;

            if (bitVersion == 64)
            {
                installLocation = GetInstallLocationForArch(RegistryView.Registry64);
                architecture = installLocation != null ? Architecture64Bit : NotInstall;
            }
            else if (bitVersion == 32)
            {
                installLocation = GetInstallLocationForArch(RegistryView.Registry32);
                architecture = installLocation != null ? Architecture32Bit : NotInstall;
            }
            else
            {
                installLocation = GetInstallLocationForArch(RegistryView.Registry64);
                if (installLocation != null)
                {
                    architecture = Architecture64Bit;
                }
                else
                {
                    installLocation = GetInstallLocationForArch(RegistryView.Registry32);
                    architecture = installLocation != null ? Architecture32Bit : NotInstall;
                }
            }

            return (architecture, installLocation ?? NotInstall);
        }

        
        private string GetInstallLocationForArch(RegistryView view)
        {
            return WinrarRegeditHelper.GetValue(
                @"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\WinRAR archiver",
                "InstallLocation",
                RegistryHive.LocalMachine,
                view
            );
        }
        public string GetWinRARVersion(RegistryView view)
        {
            return WinrarRegeditHelper.GetValue(
                @"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\WinRAR archiver",
                "DisplayVersion",
                RegistryHive.LocalMachine,
                view
            );
        }

        public bool Is32Bit()
        {
            var result = CheckWinRARInstallLocation(32);
            return result.architecture == Architecture32Bit;
        }

        public bool Is64Bit()
        {
            var result = CheckWinRARInstallLocation(64);
            return result.architecture == Architecture64Bit;
        }

        public (string architecture, string installLocation) CheckArchitectureAndInstallLocationFromUrl(string url)
        {
            var fileName = ExtractFileNameFromUrl(url);

            if (fileName.ToLower().Contains("x64"))
            {
                return CheckWinRARInstallLocation(64);
            }
            else if (fileName.ToLower().Contains("x86") || fileName.ToLower().Contains("x32"))
            {
                return CheckWinRARInstallLocation(32);
            }
            else
            {
                var check = CheckWinRARInstallLocation(0);
                if (check.architecture != NotInstall)
                    return check;

                return (NotInstall, "NotSupported");
            }
        }

        public string ExtractFileNameFromUrl(string url)
        {
            try
            {
                return Path.GetFileName(new Uri(url).AbsolutePath);
            }
            catch
            {
                var match = Regex.Match(url, @"([^/\\]+)(?=\.[a-zA-Z]+$)");
                return match.Success ? match.Value : string.Empty;
            }
        }

        public string GetDefaultInstallPathFromUrl(string url)
        {
            var installInfo = CheckArchitectureAndInstallLocationFromUrl(url);
            if (installInfo.installLocation != NotInstall)
            {
                return installInfo.installLocation;
            }

            var fileName = ExtractFileNameFromUrl(url).ToLower();
            string programFilesPath;

            if (Environment.Is64BitOperatingSystem && (fileName.Contains("x64")))
            {
                programFilesPath = Environment.GetEnvironmentVariable("ProgramW6432") ?? Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles);
            }
            else
            {
                programFilesPath = Environment.GetEnvironmentVariable("ProgramFiles(x86)") ?? Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86);
            }

            return Path.Combine(programFilesPath, "WinRAR");
        }
    }
}