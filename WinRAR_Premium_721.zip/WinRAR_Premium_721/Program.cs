﻿using System;
using System.Diagnostics;
using System.IO;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WinRAR_Premium_721.Models;
using WinRAR_Premium_721.Services;

namespace WinRAR_Premium_721
{
    static class Program
    {
        [STAThread]
        static void Main(string[] args)
        {
            if (args.Length > 0 && args[0].Equals("/setup", StringComparison.OrdinalIgnoreCase))
            {
                HandleCommandLineArgs(args).Wait();
                return;
            }

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());
        }

        private static async Task HandleCommandLineArgs(string[] args)
        {
            if (args.Length < 2)
            {
                Console.WriteLine("Lỗi: Thiếu tham số phiên bản. Vui lòng sử dụng: /setup 32bit, /setup 64bit hoặc /setup beta.");
                return;
            }

            string versionType = args[1].ToLower();
            string downloadLink = string.Empty;
            string installPath = string.Empty;

            try
            {
                WinrarApiClient apiClient = new WinrarApiClient();
                WinrarData winrarData = await apiClient.GetWinrarVersionAsync();

                if (winrarData == null)
                {
                    Console.WriteLine("Lỗi: Không thể tải dữ liệu phiên bản. Kiểm tra kết nối internet.");
                    return;
                }

                Winrar_Check winrarCheck = new Winrar_Check();
                switch (versionType)
                {
                    case "64bit":
                        downloadLink = winrarData.LinkCurrent;
                        installPath = winrarCheck.GetDefaultInstallPathFromUrl(downloadLink);
                        break;
                    case "32bit":
                        downloadLink = winrarData.LinkCurrent32;
                        installPath = winrarCheck.GetDefaultInstallPathFromUrl(downloadLink);
                        break;
                    case "beta":
                        downloadLink = winrarData.LinkBeta;
                        installPath = winrarCheck.GetDefaultInstallPathFromUrl(downloadLink);
                        break;
                    default:
                        Console.WriteLine("Lỗi: Phiên bản không hợp lệ. Vui lòng sử dụng: 32bit, 64bit hoặc beta.");
                        return;
                }

                if (string.IsNullOrEmpty(downloadLink))
                {
                    Console.WriteLine($"Lỗi: Không tìm thấy link tải cho phiên bản {versionType}.");
                    return;
                }

                Console.WriteLine($"Đang tải xuống WinRAR {versionType} từ: {downloadLink}");

                string folderPath = Path.Combine(Path.GetTempPath(), "Winrar_Setup_Temp");
                string fileName = Path.GetFileName(new Uri(downloadLink).LocalPath);
                string filePath = Path.Combine(folderPath, fileName);

                await DownloadFileAsync(downloadLink, filePath);

                Console.WriteLine($"Tải xuống hoàn tất. Bắt đầu cài đặt vào: {installPath}");

                ProcessStartInfo startInfo = new ProcessStartInfo(filePath)
                {
                    Arguments = $"/S /D\"{installPath}\"",
                    UseShellExecute = true,
                    CreateNoWindow = true,
                    Verb = "runas"
                };

                Process process = Process.Start(startInfo);
                process.WaitForExit();

                Console.WriteLine("Cài đặt hoàn tất. Đang áp dụng license...");

                string licenseContent = await apiClient.GetLicenseContentAsync();
                if (string.IsNullOrEmpty(licenseContent))
                {
                    Console.WriteLine("Lỗi: Không thể lấy nội dung license. WinRAR đã được cài đặt nhưng chưa kích hoạt.");
                    return;
                }

                string licenseFilePath = Path.Combine(installPath, "rarreg.key");
                File.WriteAllText(licenseFilePath, licenseContent, Encoding.ASCII);

                Console.WriteLine("Hoàn tất. WinRAR đã được cài đặt và kích hoạt thành công!");

                File.Delete(filePath);
                Console.WriteLine("Đã dọn dẹp file cài đặt tạm thời.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Đã xảy ra lỗi: {ex.Message}");
            }
        }

        private static async Task DownloadFileAsync(string url, string filePath)
        {
            using (HttpClient client = new HttpClient())
            {
                string directory = Path.GetDirectoryName(filePath);
                if (!Directory.Exists(directory))
                {
                    Directory.CreateDirectory(directory);
                }

                HttpResponseMessage response = await client.GetAsync(url, HttpCompletionOption.ResponseHeadersRead);
                response.EnsureSuccessStatusCode();

                using (var fileStream = new FileStream(filePath, FileMode.Create, FileAccess.Write, FileShare.None))
                using (var contentStream = await response.Content.ReadAsStreamAsync())
                {
                    await contentStream.CopyToAsync(fileStream);
                }
            }
        }
    }
}