﻿using System;
using System.Net.Http;
using System.Threading.Tasks;
using Newtonsoft.Json;
using WinRAR_Premium_721.Models;

namespace WinRAR_Premium_721.Services
{
    public class WinrarApiClient
    {
        private readonly HttpClient _httpClient;
        private const string ApiBaseUrl = "https://api.itdev721.workers.dev";

        public WinrarApiClient()
        {
            _httpClient = new HttpClient();
            _httpClient.DefaultRequestHeaders.Add("User-Agent", "Winrar_Keygen_Csharp Client");
        }

        public async Task<WinrarData> GetWinrarVersionAsync()
        {
            try
            {
                string requestUrl = $"{ApiBaseUrl}/?action=WinrarVersionJson";
                HttpResponseMessage response = await _httpClient.GetAsync(requestUrl);
                response.EnsureSuccessStatusCode();

                string jsonString = await response.Content.ReadAsStringAsync();
                WinrarData winrarData = JsonConvert.DeserializeObject<WinrarData>(jsonString);

                return winrarData;
            }
            catch (HttpRequestException ex)
            {
                Console.WriteLine($"Lỗi HTTP khi gọi API: {ex.Message}");
                return null;
            }
            catch (JsonException ex)
            {
                Console.WriteLine($"Lỗi phân tích JSON: {ex.Message}");
                return null;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Đã xảy ra lỗi không xác định: {ex.Message}");
                return null;
            }
        }

        public async Task<string> GetLicenseContentAsync()
        {
            try
            {
                string requestUrl = $"{ApiBaseUrl}/rarreg.key";
                HttpResponseMessage response = await _httpClient.GetAsync(requestUrl);
                response.EnsureSuccessStatusCode();

                string licenseContent = await response.Content.ReadAsStringAsync();
                return licenseContent;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Lỗi khi tải nội dung license: {ex.Message}");
                return null;
            }
        }
    }
}