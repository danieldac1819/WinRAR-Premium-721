﻿using Microsoft.Win32;
using System;

namespace WinRAR_Premium_721.Services
{
    public static class WinrarRegeditHelper
    {
        /// <summary>
        /// Mở RegistryKey gốc với tùy chọn Hive và View.
        /// </summary>
        private static RegistryKey OpenBaseKey(RegistryHive hive, RegistryView view)
        {
            return RegistryKey.OpenBaseKey(hive, view);
        }

        public static bool CreateKey(string parentKeyPath, string newSubKeyName, RegistryHive hive = RegistryHive.LocalMachine, RegistryView view = RegistryView.Default)
        {
            try
            {
                using (RegistryKey baseKey = OpenBaseKey(hive, view))
                using (RegistryKey parentKey = baseKey.OpenSubKey(parentKeyPath, writable: true))
                {
                    if (parentKey != null)
                    {
                        parentKey.CreateSubKey(newSubKeyName);
                        return true;
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[CreateKey] Error: {ex.Message}");
            }
            return false;
        }

        public static bool DeleteKey(string parentKeyPath, string subKeyName, RegistryHive hive = RegistryHive.LocalMachine, RegistryView view = RegistryView.Default)
        {
            try
            {
                using (RegistryKey baseKey = OpenBaseKey(hive, view))
                using (RegistryKey parentKey = baseKey.OpenSubKey(parentKeyPath, writable: true))
                {
                    if (parentKey != null)
                    {
                        parentKey.DeleteSubKey(subKeyName, throwOnMissingSubKey: false);
                        return true;
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[DeleteKey] Error: {ex.Message}");
            }
            return false;
        }

        public static bool SetValue(string keyPath, string valueName, object valueData, RegistryValueKind kind = RegistryValueKind.String, RegistryHive hive = RegistryHive.LocalMachine, RegistryView view = RegistryView.Default)
        {
            try
            {
                using (RegistryKey baseKey = OpenBaseKey(hive, view))
                using (RegistryKey key = baseKey.OpenSubKey(keyPath, writable: true))
                {
                    if (key != null)
                    {
                        key.SetValue(valueName, valueData, kind);
                        return true;
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[SetValue] Error: {ex.Message}");
            }
            return false;
        }

        public static bool DeleteValue(string keyPath, string valueName, RegistryHive hive = RegistryHive.LocalMachine, RegistryView view = RegistryView.Default)
        {
            try
            {
                using (RegistryKey baseKey = OpenBaseKey(hive, view))
                using (RegistryKey key = baseKey.OpenSubKey(keyPath, writable: true))
                {
                    if (key != null)
                    {
                        key.DeleteValue(valueName, throwOnMissingValue: false);
                        return true;
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[DeleteValue] Error: {ex.Message}");
            }
            return false;
        }

        public static string GetValue(string keyPath, string valueName, RegistryHive hive = RegistryHive.LocalMachine, RegistryView view = RegistryView.Default)
        {
            try
            {
                using (RegistryKey baseKey = OpenBaseKey(hive, view))
                using (RegistryKey key = baseKey.OpenSubKey(keyPath, writable: false))
                {
                    if (key != null)
                    {
                        object value = key.GetValue(valueName);
                        return value?.ToString();
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[GetValue] Error: {ex.Message}");
            }
            return null;
        }
    }
}
